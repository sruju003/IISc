from flask import Flask, render_template, request
import os

app = Flask(__name__)

def read_file(filepath):
    with open(filepath, 'r', encoding='utf-8') as file:
        return file.readlines()

def load_keywords(keyword_folder):
    keywords = {}
    for filename in os.listdir(keyword_folder):
        if filename.endswith('.txt'):
            keywords[filename] = [line.strip() for line in read_file(os.path.join(keyword_folder, filename))]
    return keywords

def map_keywords_to_ifc(ifc_lines, keywords):
    keyword_map = {}
    for i, line in enumerate(ifc_lines):
        for file, words in keywords.items():
            for word in words:
                if word in line:
                    if word not in keyword_map:
                        keyword_map[word] = []
                    keyword_map[word].append((i, line))
    return keyword_map

# Load files and keywords
IFC_FILE_PATH = "C:/Users/SRUJANA GOLLA/Desktop/IISc/prajwal/mainifcthing/ifc/file.ifc"
KEYWORD_FOLDER_PATH = "C:/Users/SRUJANA GOLLA/Desktop/IISc/prajwal/mainifcthing/keywords"
ifc_lines = read_file(IFC_FILE_PATH)
keywords = load_keywords(KEYWORD_FOLDER_PATH)
keyword_map = map_keywords_to_ifc(ifc_lines, keywords)

@app.route('/')
def index():
    all_keywords = sorted(keyword_map.keys())
    return render_template('index.html', keywords=all_keywords)

@app.route('/search', methods=['POST'])
def search():
    selected_keyword = request.form['keyword']
    lines = keyword_map.get(selected_keyword, [])
    return render_template('search_results.html', keyword=selected_keyword, lines=lines)

if __name__ == '__main__':
    app.run(debug=True)
