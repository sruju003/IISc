import os

def read_file(filepath):
    with open(filepath, 'r', encoding='utf-8') as file:
        return file.readlines()

def load_keywords(keyword_folder):
    keywords = {}
    for filename in os.listdir(keyword_folder):
        if filename.endswith('.txt'):
            keywords[filename] = read_file(os.path.join(keyword_folder, filename))
    return keywords

def map_keywords_to_ifc(ifc_lines, keywords):
    keyword_map = {}
    for i, line in enumerate(ifc_lines):
        for file, words in keywords.items():
            for word in words:
                word = word.strip()
                if word in line:
                    if word not in keyword_map:
                        keyword_map[word] = []
                    keyword_map[word].append((i, line))
    return keyword_map
