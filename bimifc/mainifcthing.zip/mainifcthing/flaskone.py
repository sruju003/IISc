from flask import Flask, render_template, request
import os

app = Flask(__name__)

# Load files and keywords
IFC_FILE_PATH = 'path/to/your/ifc/file.ifc'
KEYWORD_FOLDER_PATH = 'path/to/your/keyword/files'
ifc_lines = read_file(IFC_FILE_PATH)
keywords = load_keywords(KEYWORD_FOLDER_PATH)
keyword_map = map_keywords_to_ifc(ifc_lines, keywords)

@app.route('/')
def index():
    all_keywords = sorted(set(keyword for words in keywords.values() for keyword in words))
    return render_template('index.html', keywords=all_keywords)

@app.route('/search', methods=['POST'])
def search():
    selected_keyword = request.form['keyword']
    if selected_keyword in keyword_map:
        lines = keyword_map[selected_keyword]
    else:
        lines = []
    return render_template('search_results.html', keyword=selected_keyword, lines=lines)

if __name__ == '__main__':
    app.run(debug=True)
